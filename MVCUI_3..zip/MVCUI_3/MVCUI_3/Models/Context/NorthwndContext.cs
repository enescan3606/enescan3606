﻿using Microsoft.EntityFrameworkCore;

namespace MVCUI_3.Models.Context
{
    public class NorthwndContext : DbContext
    {
        public DbSet<Product> Products{ get; set; }
        public DbSet<Supplier> Suppliers{ get; set; }
        public DbSet<Category> Categories{ get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer($"Server = LAB8-OGRETMEN\\SQLEXPRESS;Database=NORTHWND;Trusted_Connection=True;");
        }
    }
}
