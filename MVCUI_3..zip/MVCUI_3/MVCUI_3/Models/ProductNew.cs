﻿namespace MVCUI_3.Models
{
    public class ProductNew
    {
        public List<Category> Categories{ get; set; }
        public List<Supplier> Suppliers{ get; set; }
    }
}
