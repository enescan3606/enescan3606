﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVCUI_3.Models;
using MVCUI_3.Models.Context;

namespace MVCUI_3.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult Details(int id)
        {

            var ctx = new NorthwndContext();

            var product = ctx.Products
                .Include("Category")
                .Include("Supplier")
                .SingleOrDefault(x => x.ProductId == id);



            return View(product);
        }
       


        public ViewResult New()
        {
            var cnt = new NorthwndContext();
            var model = new ProductNew();

            model.Categories = cnt.Categories.ToList();
            model.Suppliers = cnt.Suppliers.ToList();

            return View(model);
        }


    }
}
