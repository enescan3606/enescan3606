﻿using Microsoft.AspNetCore.Mvc;
using MVCUI_3.Models;
using MVCUI_3.Models.Context;
using System.Diagnostics;

namespace MVCUI_3.Controllers
{
    public class HomeController : Controller
    {


        public ViewResult Index(int id)
        {

            NorthwndContext cnt = new NorthwndContext();
            IndexModel model = new IndexModel();

            model.Categories = cnt.Categories.ToList();


            if (id == 0)
            {
                model.Products = cnt.Products.ToList();
                // model.Title = "Tüm Ürünler";
                ViewBag.Title = "Tüm Ürünler";
                ViewBag.ActiveCategoryName = "Tümü";
            }
            else
            {
                model.Products = cnt.Products.Where(x => x.CategoryId == id).ToList();
                var category = cnt.Categories.SingleOrDefault(x => x.CategoryId == id);
                // model.Title = $"{category.CategoryName} ait Ürünler"; 
                ViewBag.Title = $"{category.CategoryName} ait Ürünler";
                ViewBag.ActiveCategoryName = category.CategoryName;
            }

            return View(model);
        }


    }
}