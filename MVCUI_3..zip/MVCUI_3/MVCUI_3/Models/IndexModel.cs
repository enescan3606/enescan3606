﻿namespace MVCUI_3.Models
{
    public class IndexModel
    {
        public List<Product> Products { get; set; }
        public List<Category> Categories { get; set; }
        public string  Title{ get; set; }
    }
}
